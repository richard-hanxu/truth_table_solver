import dearpygui.dearpygui as dpg
import truthtable as tt

num_inputs = 2
num_rows = 4
true_dict = {0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E', 5: 'F', 6: 'G'}
false_dict = {0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e', 5: 'f', 6: 'g'}

def create_table(sender, app_data, user_data):
    num_ins = dpg.get_value('num_inputs')
    num_r = dpg.get_value('num_rows')
    global num_inputs
    global num_rows
    if num_inputs < 2 or num_rows < 4:
        return
    else:
        num_inputs = num_ins
        num_rows = num_r
    delete_table(sender, app_data)
    with dpg.table(tag='table', header_row=True, parent=user_data, width=(num_inputs + 1) * 120):
        for i in range(num_inputs):
            dpg.add_table_column(label=true_dict[i], width=120)
        dpg.add_table_column(label='Output', width=120)

        for i in range(0, num_rows):
            with dpg.table_row():
                for j in range(0, num_inputs + 1):
                    with dpg.table_cell():
                        dpg.add_input_int(min_value=0, max_value=1, min_clamped=True, max_clamped=True, width=100, tag=f'{i},{j}')

def delete_table(sender, app_data):
    if dpg.does_item_exist('table'):
        dpg.delete_item('table')

def get_minterms(sender, app_data):
    global num_inputs
    minterms = []
    for i in range(0, num_rows):
        if(dpg.get_value(f'{i},{num_inputs}') == 1):
            s = ''
            for j in range(0, num_inputs):
                s += str(dpg.get_value(f'{i},{j}'))
            minterms.append(s)
    pis = get_PIs(minterms)
    b_exps = get_bexps(pis)
    #print(f'pis: {pis}, b_exps: {b_exps}')
    output_bexps(b_exps)

def get_PIs(minterms):
    pis = []
    groups = tt.get_PIs(minterms, num_inputs)
    for g in groups:
        for term in g:
            pis.append(term[1])
    return pis

def get_bexps(pis):
    global true_dict
    global false_dict
    b_exps = []
    for pi in pis:
        s = ''
        for i in range(len(pi)):
            if pi[i] == '1':
                s += true_dict[i]
            elif pi[i] == '0':
                s += false_dict[i]
        b_exps.append(s)
    return b_exps

def output_bexps(b_exps):
    print('Uppercase -> 1/True, lowercase -> 0/False')
    print(' + '.join(b_exps))
    
def main():
    dpg.create_context()
    dpg.create_viewport(title='Truth Table Solver', width=960, height=720)

    with dpg.theme() as global_theme:

        with dpg.theme_component(dpg.mvInputInt):
            dpg.add_theme_color(dpg.mvThemeCol_FrameBg, (54, 61, 65), category=dpg.mvThemeCat_Core)
            dpg.add_theme_style(dpg.mvStyleVar_FrameRounding, 3, category=dpg.mvThemeCat_Core)

    with dpg.window(label="Example Window", tag="Primary Window") as main_win:

        dpg.add_text('Welcome to the Prime Indicator Simplifier!')
        dpg.add_text('This program uses the Quine McCluskey algorithm to fully simplify any boolean expression of minterms!') 
        dpg.add_text('Control the number of independent variables in your expressions (max. of 6) and the number of') 
        dpg.add_text('rows/terms you need to simplify. The simplified expression will be outputted in your terminal.')
        dpg.add_text()
        dpg.add_separator()
        dpg.add_text('(You do not need to use every line in each row)')

        dpg.add_input_int(label='Independent Variables', tag='num_inputs', min_value=2, max_value=6, min_clamped=True, max_clamped=False, width=100)
        dpg.add_input_int(label='Number of Rows', tag='num_rows', min_value=4, max_value=12, min_clamped=True, max_clamped=False, width=100)
        dpg.add_button(label='Apply Changes', callback=create_table, user_data=main_win)
        dpg.add_text()
        dpg.add_button(tag="calculate", label="Get Prime Indicators")
        dpg.set_item_callback("calculate", get_minterms)
        
        with dpg.table(tag='table', header_row=True, width=360):
            for i in range(num_inputs):
                dpg.add_table_column(label=true_dict[i], width=120)
            dpg.add_table_column(label='Output', width=120)

            for i in range(0, num_rows):
                with dpg.table_row():
                    for j in range(0, num_inputs + 1):
                        with dpg.table_cell():
                            dpg.add_input_int(min_value=0, max_value=1, min_clamped=True, max_clamped=True, width=100, tag=f'{i},{j}')

    dpg.bind_theme(global_theme)
    dpg.setup_dearpygui()
    dpg.show_viewport()
    dpg.set_primary_window("Primary Window", True)
    dpg.start_dearpygui()
    dpg.destroy_context()

main()