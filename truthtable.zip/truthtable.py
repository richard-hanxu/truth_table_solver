# This truth table simplification uses the Quine McCluskey Method
# For more information: https://www.geeksforgeeks.org/quine-mccluskey-method/#:~:text=Quine%20McCluskey%20method%20also%20known,uses%20an%20automatic%20simplification%20routine. 

# Input: an m x 1 matrix, int bits representing the number of inputs
def get_PIs(numbers : list, bits):
    
    # Binary representation
    bin_rep = [[] for i in range(bits + 1)]
    for n in numbers:
        cnt = 0
        for c in n:
            if c == '1':
                cnt += 1
        bin_rep[cnt].append([[n], n, 0]) # [[n], n, 0] represents a minterm
    
    # Note on the relevance of minterm[2]:
    # minterm[2] = 0: Has not combined with any other minterm
    # minterm[2] = 1: Combined with minterm in higher group (if it has also combined with a minterm in lower group, this takes precedence)
    # minterm[2] = 2: Combined with minterm in lower group
    counter = 0
    groupnum = 1
    while(counter <= bits):
        groupnum = 1
        while(groupnum <= bits):
            # term1 is the minterm in higher group
            for term1 in bin_rep[groupnum]:
                # term2 is the minterm in lower group
                for term2 in bin_rep[groupnum - 1]:
                    # Compare minterms using the second columns, combine minterms using the first columns
                    xor = ''
                    for i in range(len(term1[1])):
                        xor += ('1', '0')[term1[1][i] == term2[1][i] or term1[1][i] == '-' or term2[1][i] == '-']                               
                    difference_index = [i for i, val in enumerate(xor) if val == '1']
                    if len(difference_index) == 1:
                        term2[0].extend(term1[0])
                        term2[1] = term2[1][0:difference_index[0]] + '-' + term2[1][difference_index[0] + 1:]
                        term1[2] = 2
                        term2[2] = 1
            groupnum += 1
        # Loop through all the minterms, and remove any minterm if minterm[2] = 2
        # minterm[2] = 2 implies that it cannot be a PI (it is completely absorbed)
        for g in bin_rep:
            for term in g:
                if term[2] == 2:
                    g.remove(term)
                else:
                    # Reset all "combine indicator" values to 0
                    term[2] = 0
        counter += 1

    return bin_rep
                
def test():
    term1 = [['0010', '0011'], '001-']
    term2 = [['1110', '0110'], '-110']
    xor = ''
    for i in range(len(term1[1])):
        xor += ('1', '0')[term1[1][i] == term2[1][i] or term1[1][i] == '-' or term2[1][i] == '-']        
    print(xor)                       
    difference_index = [i for i, val in enumerate(xor) if val == '1']
    if len(difference_index) == 1:
        print('t')
        term1[0].extend(term2[0])
        term1[1] = term1[1][0:difference_index[0]] + '-' + term1[1][difference_index[0] + 1:]
    print(term1)
    print(term2)

def test2(numbers : list, bits):
    # Binary representation
    bin_rep = [[] for i in range(bits + 1)]
    print(bin_rep)
    for n in numbers:
        cnt = 0
        for c in n:
            if c == '1':
                cnt += 1
        print(cnt)
        bin_rep[cnt].append([[n], n])
    print(bin_rep)

#test()
#test2(["0000", "0001", "1111"], 4)

if __name__ == '__main__':
    for group in get_PIs(["0000", "0001", "0101", "1111"], 4):
        print(group)



